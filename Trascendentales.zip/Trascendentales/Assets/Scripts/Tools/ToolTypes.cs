﻿public enum ToolTypes
{
    Brush = 0,
    Ruler = 1,
    Squad = 2,
    Compass = 3,
    Eraser = 4
}